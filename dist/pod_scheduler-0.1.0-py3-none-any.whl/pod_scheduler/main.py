import time
import random
import json


from schedule import ScheduleJob

from kubernetes import client, config, watch

config.load_kube_config()
v1=client.CoreV1Api()

scheduler_name = "ssi"

def nodes_available():
    ready_nodes = []
    for n in v1.list_node().items:
            for status in n.status.conditions:
                if status.status == "True" and status.type == "Ready":
                    ready_nodes.append(n.metadata.name)

    return ready_nodes


def list_all_pods():
    pods = []
    for pod in v1.list_pod_for_all_namespaces().items:
        if pod.spec.scheduler_name == scheduler_name:
            name = pod.metadata.name
            node_name = pod.spec.node_name
            priority = int(pod.metadata.annotations.get("priority"))
            pods.append((name, node_name, priority))
    return pods

def schedule(name, node, namespace="default"):
    metadata = (client.V1ObjectMeta(name=name))
    target=client.V1ObjectReference(kind="Node", api_version="v1", name=node)


    binding = client.V1Binding(metadata=metadata, target=target)

    # https://github.com/kubernetes-client/python/issues/547
    # _preload_content set to False due to an unfixed bug in python
    v1.create_namespaced_binding(namespace=namespace, body=binding, _preload_content=False)
    
    return

def main():
    w = watch.Watch()
    for event in w.stream(v1.list_namespaced_pod, "default"):
        if event['object'].status.phase == "Pending" and event['object'].spec.scheduler_name == scheduler_name:
            print("Found something that meets the condition")
            try:
                schedule_pods()
            except client.rest.ApiException as e:
                print(json.loads(e.body)['message'])
                    

def podsToSchedule(pod):
    (_, node, _) = pod
    if node == None:
        return True
    
    return False

def available_unique_nodes(nodes, pods):
    nodes = set(nodes)
    nodes_taken = []
    for pod in pods:
        if pod[1]:
            nodes_taken.append(pod[1])


    return list(nodes.difference(set(nodes_taken)))



def schedule_pods():
    pods = list_all_pods()
    availableNodes = available_unique_nodes(nodes_available(), pods)

    if len(availableNodes) == 0:
        print("We've ran out of nodes")
        return

    pods = filter(podsToSchedule, pods)
    pods = sorted(pods, key=lambda x: x[2], reverse=True)

    node = availableNodes.pop()

    for pod in filter(podsToSchedule, pods):
        schedule(pod[0], node, namespace="default")
        print(node)
        if len(availableNodes) > 0:
            node = availableNodes.pop()
        else:
            print("We've ran out of nodes")
            break




if __name__ == '__main__':
    main()