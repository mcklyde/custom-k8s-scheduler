class ScheduleJob:
    
    def __init__(self, deployType, name, node, priority):
        self.deployType = deployType
        self.name = name
        self.node = node